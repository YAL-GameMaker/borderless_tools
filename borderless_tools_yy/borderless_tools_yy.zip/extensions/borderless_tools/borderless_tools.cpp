#pragma once
#include "stdafx.h"
#include <vector>
#if ((defined(_MSVC_LANG) && _MSVC_LANG >= 201703L) || __cplusplus >= 201703L)
#include <optional>
#endif
#include <stdint.h>
#include <cstring>
#include <tuple>
using namespace std;

#define dllg /* tag */

#if defined(WIN32)
#define dllx extern "C" __declspec(dllexport)
#elif defined(GNUC)
#define dllx extern "C" __attribute__ ((visibility("default"))) 
#else
#define dllx extern "C"
#endif

#ifdef _WINDEF_
typedef HWND GAME_HWND;
#endif

struct gml_buffer {
private:
	uint8_t* _data;
	int32_t _size;
	int32_t _tell;
public:
	gml_buffer() : _data(nullptr), _tell(0), _size(0) {}
	gml_buffer(uint8_t* data, int32_t size, int32_t tell) : _data(data), _size(size), _tell(tell) {}

	inline uint8_t* data() { return _data; }
	inline int32_t tell() { return _tell; }
	inline int32_t size() { return _size; }
};

class gml_istream {
	uint8_t* pos;
	uint8_t* start;
public:
	gml_istream(void* origin) : pos((uint8_t*)origin), start((uint8_t*)origin) {}

	template<class T> T read() {
		static_assert(std::is_trivially_copyable_v<T>, "T must be trivially copyable to be read");
		T result{};
		std::memcpy(&result, pos, sizeof(T));
		pos += sizeof(T);
		return result;
	}

	char* read_string() {
		char* r = (char*)pos;
		while (*pos != 0) pos++;
		pos++;
		return r;
	}

	template<class T> std::vector<T> read_vector() {
		static_assert(std::is_trivially_copyable_v<T>, "T must be trivially copyable to be read");
		auto n = read<uint32_t>();
		std::vector<T> vec(n);
		std::memcpy(vec.data(), pos, sizeof(T) * n);
		pos += sizeof(T) * n;
		return vec;
	}

	gml_buffer read_gml_buffer() {
		auto _data = (uint8_t*)read<int64_t>();
		auto _size = read<int32_t>();
		auto _tell = read<int32_t>();
		return gml_buffer(_data, _size, _tell);
	}

	#pragma region Tuples
	#if ((defined(_MSVC_LANG) && _MSVC_LANG >= 201703L) || __cplusplus >= 201703L)
	template<typename... Args>
	std::tuple<Args...> read_tuple() {
		std::tuple<Args...> tup;
		std::apply([this](auto&&... arg) {
			((
				arg = this->read<std::remove_reference_t<decltype(arg)>>()
				), ...);
			}, tup);
		return tup;
	}

	template<class T> optional<T> read_optional() {
		if (read<bool>()) {
			return read<T>;
		} else return {};
	}
	#else
	template<class A, class B> std::tuple<A, B> read_tuple() {
		A a = read<A>();
		B b = read<B>();
		return std::tuple<A, B>(a, b);
	}

	template<class A, class B, class C> std::tuple<A, B, C> read_tuple() {
		A a = read<A>();
		B b = read<B>();
		C c = read<C>();
		return std::tuple<A, B, C>(a, b, c);
	}

	template<class A, class B, class C, class D> std::tuple<A, B, C, D> read_tuple() {
		A a = read<A>();
		B b = read<B>();
		C c = read<C>();
		D d = read<d>();
		return std::tuple<A, B, C, D>(a, b, c, d);
	}
	#endif
};

class gml_ostream {
	uint8_t* pos;
	uint8_t* start;
public:
	gml_ostream(void* origin) : pos((uint8_t*)origin), start((uint8_t*)origin) {}

	template<class T> void write(T val) {
		static_assert(std::is_trivially_copyable_v<T>, "T must be trivially copyable to be write");
		memcpy(pos, &val, sizeof(T));
		pos += sizeof(T);
	}

	void write_string(const char* s) {
		for (int i = 0; s[i] != 0; i++) write<char>(s[i]);
		write<char>(0);
	}

	template<class T> void write_vector(std::vector<T>& vec) {
		static_assert(std::is_trivially_copyable_v<T>, "T must be trivially copyable to be write");
		auto n = vec.size();
		write<uint32_t>(n);
		memcpy(pos, vec.data(), n * sizeof(T));
		pos += n * sizeof(T);
	}

	#if ((defined(_MSVC_LANG) && _MSVC_LANG >= 201703L) || __cplusplus >= 201703L)
	template<typename... Args>
	void write_tuple(std::tuple<Args...> tup) {
		std::apply([this](auto&&... arg) {
			(this->write(arg), ...);
			}, tup);
	}

	template<class T> void write_optional(optional<T>& val) {
		auto hasValue = val.has_value();
		write<bool>(hasValue);
		if (hasValue) write<T>(val.value());
	}
	#else
	template<class A, class B> void write_tuple(std::tuple<A, B>& tup) {
		write<A>(std::get<0>(tup));
		write<B>(std::get<1>(tup));
	}
	template<class A, class B, class C> void write_tuple(std::tuple<A, B, C>& tup) {
		write<A>(std::get<0>(tup));
		write<B>(std::get<1>(tup));
		write<C>(std::get<2>(tup));
	}
	template<class A, class B, class C, class D> void write_tuple(std::tuple<A, B, C, D>& tup) {
		write<A>(std::get<0>(tup));
		write<B>(std::get<1>(tup));
		write<C>(std::get<2>(tup));
		write<D>(std::get<3>(tup));
	}
	#endif
};
//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by borderless_tools.rc

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#ifdef _WINDOWS
	#include "targetver.h"
	
	#define WIN32_LEAN_AND_MEAN // Exclude rarely-used stuff from Windows headers
	#include <windows.h>
#endif

#if defined(WIN32)
#define dllx extern "C" __declspec(dllexport)
#elif defined(GNUC)
#define dllx extern "C" __attribute__ ((visibility("default"))) 
#else
#define dllx extern "C"
#endif

#define _trace // requires user32.lib;Kernel32.lib
#define tiny_malloc
#define tiny_memcpy

#ifdef _trace
#ifdef _WINDOWS
void trace(const char* format, ...);
#else
#define trace(...) { printf("[borderless_tools:%d] ", __LINE__); printf(__VA_ARGS__); printf("\n"); fflush(stdout); }
#endif
#endif

#include "gml_ext.h"

// TODO: reference additional headers your program requires here
#pragma once

// Including SDKDDKVer.h defines the highest available Windows platform.

// If you wish to build your application for a previous Windows platform, include WinSDKVer.h and
// set the _WIN32_WINNT macro to the platform you wish to support before including SDKDDKVer.h.

#include <SDKDDKVer.h>
#include "gml_ext.h"
/// @author YellowAfterlife

#include "stdafx.h"
#include <dwmapi.h>

template<class T>
class gml_ovector {
private:
	T* _data;
	int32_t _size;
	int32_t _capacity;
public:
	void init(int32_t capacity = 4) {
		_capacity = capacity;
		_data = (T*)malloc(sizeof(T) * capacity);
		_size = 0;
	}
	void cleanup() {
		if (_data) {
			free(_data);
			_data = nullptr;
		}
	}
	void clear() { _size = 0; }
	T* data() { return _data; }
	int32_t size() { return _size; }
	T operator[](int index) const { return _data[index]; }
	T& operator[](int index) { return _data[index]; }
	void push_back(T value) {
		if (_size >= _capacity) {
			_capacity *= 2;
			_data = (T*)realloc(_data, _capacity);
		}
		_data[_size++] = value;
	}
};

static HWND hwnd;
static TRACKMOUSEEVENT hwnd_tme;
static bool hwnd_tme_bound = false;
static bool mouse_in_window = false;
dllx double borderless_tools_mouse_in_window() {
	return mouse_in_window;
}

static bool has_shadow;
dllx void borderless_tools_set_shadow(double _enable) {
	bool enable = _enable > 0.5;
	has_shadow = enable;
	auto pad = enable ? 1 : 0;
	MARGINS m{ pad, pad, pad, pad };
	DwmExtendFrameIntoClientArea(hwnd, &m);
	SetWindowLong(hwnd, GWL_STYLE, GetWindowLong(hwnd, GWL_STYLE) | WS_CAPTION);
	SetWindowPos(hwnd, nullptr, 0, 0, 0, 0, SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED);
	//trace("shadow: %d", enable);
}

WNDPROC window_command_proc_base = nullptr;
LRESULT window_command_proc_hook(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	//printf("msg=%d\n", msg); fflush(stdout);
	switch (msg) {
		case WM_NCCALCSIZE:
			//trace("NCCALCSIZE(wp=%d,lp=%d,shadow=%d)", wParam, lParam, has_shadow);
			if (has_shadow && wParam == TRUE) {
				SetWindowLong(hwnd, DWLP_MSGRESULT, 0);
				return TRUE;
			}
			return FALSE;
		case WM_MOUSEMOVE:
			if (!hwnd_tme_bound) {
				//trace("Enter");
				hwnd_tme_bound = true;
				mouse_in_window = true;
				TrackMouseEvent(&hwnd_tme);
			}
			break;
		case WM_MOUSELEAVE:
			//trace("Leave");
			hwnd_tme_bound = false;
			mouse_in_window = false;
			break;
	}
	return CallWindowProc(window_command_proc_base, hwnd, msg, wParam, lParam);
}

dllx void borderless_tools_init_raw(void* _hwnd) {
	if (hwnd) return;
	hwnd = (HWND)_hwnd;
	hwnd_tme_bound = true;
	mouse_in_window = true;
	hwnd_tme = {};
	hwnd_tme.cbSize = sizeof(hwnd_tme);
	hwnd_tme.dwFlags = TME_LEAVE;
	hwnd_tme.hwndTrack = hwnd;
	hwnd_tme.dwHoverTime = 1;
	TrackMouseEvent(&hwnd_tme);
	window_command_proc_base = (WNDPROC)SetWindowLongPtr(hwnd, GWLP_WNDPROC, (LONG_PTR)window_command_proc_hook);
	SetWindowLong(hwnd, GWL_STYLE, GetWindowLong(hwnd, GWL_STYLE) | WS_CAPTION);
	borderless_tools_set_shadow(true);
}

dllx void borderless_tools_syscommand(double _sc) {
	SendMessage(hwnd, WM_SYSCOMMAND, (int)_sc, 0);
}

///~
#define display_measure_all_name_len 32
struct borderless_tools_get_monitors_t {
	struct { int left, top, width, height; } monitor;
	struct { int left, top, width, height; } workspace;
	int flags;
};
static gml_ovector<borderless_tools_get_monitors_t> borderless_tools_get_monitors_acc;

static void init() {
	hwnd = 0;
	has_shadow = false;
	borderless_tools_get_monitors_acc.init();
}

BOOL CALLBACK display_measure_all_cb(HMONITOR m, HDC hdc, LPRECT rect, LPARAM p) {
	MONITORINFO inf;
	inf.cbSize = sizeof(inf);
	if (!GetMonitorInfoA(m, &inf)) return TRUE;
	static_assert(display_measure_all_name_len == CCHDEVICENAME, "display_measure_all_name_len doesn't match CCHDEVICENAME");
	borderless_tools_get_monitors_t out;
	out.monitor.left   = inf.rcMonitor.left;
	out.monitor.width  = inf.rcMonitor.right - inf.rcMonitor.left;
	out.monitor.top    = inf.rcMonitor.top;
	out.monitor.height = inf.rcMonitor.bottom - inf.rcMonitor.top;
	out.workspace.left   = inf.rcWork.left;
	out.workspace.width  = inf.rcWork.right - inf.rcWork.left;
	out.workspace.top    = inf.rcWork.top;
	out.workspace.height = inf.rcWork.bottom - inf.rcWork.top;
	out.flags = inf.dwFlags;
	borderless_tools_get_monitors_acc.push_back(out);
	return TRUE;
}

dllx double borderless_tools_get_monitors_1() {
	borderless_tools_get_monitors_acc.clear();
	EnumDisplayMonitors(NULL, NULL, display_measure_all_cb, 0);
	return borderless_tools_get_monitors_acc.size();
}
dllx double borderless_tools_get_monitors_2(borderless_tools_get_monitors_t* out) {
	auto n = borderless_tools_get_monitors_acc.size();
	for (auto i = 0; i < n; i++) out[i] = borderless_tools_get_monitors_acc.data()[i];
	return 1;
}

dllx double borderless_tools_double_click_time() {
	return GetDoubleClickTime();
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved) {
	switch (fdwReason) {
		case DLL_PROCESS_ATTACH:
			init();
			break;
		case DLL_PROCESS_DETACH:
			borderless_tools_get_monitors_acc.cleanup();
			break;
	}
	return TRUE;
}// stdafx.cpp : source file that includes just the standard includes
// GMSDLL.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"
#include <strsafe.h>

#if _WINDOWS
// http://computer-programming-forum.com/7-vc.net/07649664cea3e3d7.htm
extern "C" int _fltused = 0;
#endif

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
#ifdef _trace
#ifdef _WINDOWS
// https://yal.cc/printf-without-standard-library/
void trace(const char* pszFormat, ...) {
	char buf[1025];
	va_list argList;
	va_start(argList, pszFormat);
	wvsprintfA(buf, pszFormat, argList);
	va_end(argList);
	DWORD done;
	auto len = strlen(buf);
	buf[len] = '\n';
	buf[++len] = 0;
	WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), buf, len, &done, NULL);
}
#endif
#endif

#ifdef NDEBUG
#pragma warning(disable: 28251 28252)

#ifdef tiny_memset
#pragma function(memset)
void* __cdecl memset(void* _Dst, _In_ int _Val, _In_ size_t _Size) {
	auto ptr = static_cast<uint8_t*>(_Dst);
	for (; _Size != 0; _Size--) *ptr++ = _Val;
	return _Dst;
}
#endif

#ifdef tiny_memcpy
#pragma function(memcpy)
void* memcpy(void* _Dst, const void* _Src, size_t _Size) {
	auto src = static_cast<const uint8_t*>(_Src);
	auto dst = static_cast<uint8_t*>(_Dst);
	for (; _Size != 0; _Size--) *dst++ = *src++;
	return _Dst;
}
#endif

#ifdef tiny_malloc
void* __cdecl malloc(size_t _Size) {
	return HeapAlloc(GetProcessHeap(), 0, _Size);
}
void* __cdecl realloc(void* _Block, size_t _Size) {
	return HeapReAlloc(GetProcessHeap(), 0, _Block, _Size);
}
void __cdecl free(void* _Block) {
	HeapFree(GetProcessHeap(), 0, _Block);
}
#endif

#pragma warning(default: 28251 28252)
#endif
